import java.util.*;

class SomarDoisNumeros {
	public static Scanner sc = new Scanner(System.in);
	
	public static void main (String[] args) {
	       int numero1, numero2, soma;
	       
	       System.out.println("Digite um número");
	       numero1 = sc.nextInt();
	       System.out.println("Digite outro número");
	       numero2 = sc.nextInt();
	       
	       soma =  numero1 + numero2;
	       
	       System.out.println("Soma:" + soma);
	}

}
